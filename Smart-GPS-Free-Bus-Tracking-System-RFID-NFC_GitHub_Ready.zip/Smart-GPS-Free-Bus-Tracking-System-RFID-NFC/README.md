# Smart GPS-Free Bus Tracking System Using RFID & NFC

## Project Overview
This repository contains the planning, requirements analysis, system diagrams and sample data for a proposed **Smart GPS-Free Bus Tracking System Using RFID and NFC**.

The project explores a checkpoint-based approach for monitoring bus movement without depending primarily on continuous GPS tracking. Each bus is assigned a unique RFID identifier. RFID readers installed at predefined checkpoints detect the bus and generate a movement event. An ESP32 or compatible controller validates the event, records the checkpoint and timestamp, stores the event locally when required, and synchronizes it with a backend database.

NFC can be used for authorized operator identification or administrative interaction.

## Problem Statement
Conventional GPS-based tracking can be affected by signal obstruction, covered areas, network interruptions and continuous service requirements. This project proposes a controlled, event-based alternative in which a bus location is represented by its **latest confirmed checkpoint**.

The system does not claim an exact continuous location between checkpoints. Instead, it provides verified movement information based on actual RFID detection events.

## Project Objectives
- Develop a GPS-independent prototype for monitoring bus movement using RFID checkpoints.
- Assign unique identifiers to registered buses and checkpoints.
- Record Bus ID, Checkpoint ID, timestamp and synchronization status.
- Integrate RFID, NFC, microcontroller processing and data communication.
- Prevent unnecessary data loss during temporary network interruptions using local buffering.
- Display the latest confirmed bus checkpoint and recent event history.
- Evaluate common failures, risks, resources, timeline and prototype budget.

## Proposed System Workflow
1. A bus approaches a predefined checkpoint.
2. The RFID reader detects the unique RFID tag.
3. The controller validates the Bus ID and Checkpoint ID.
4. A timestamped movement event is created.
5. The event is stored locally.
6. The controller sends the event to the backend when connectivity is available.
7. The database updates the latest confirmed checkpoint.
8. The monitoring dashboard displays the current verified status.

## Example Event
| Event ID | Bus ID | Checkpoint | Timestamp | Status |
|---|---|---|---|---|
| 10458 | BUS-12 | CP-03 | 2026-08-20 08:42:15 | Synced |

## Prototype Assumptions
- 5 prototype buses
- 8 predefined checkpoints
- Approximately 16 checkpoint events per round trip
- Approximately 320 events per day in the planned prototype case
- Local buffering during temporary network failures
- Latest successful checkpoint shown as the last confirmed location

## Repository Structure
```text
Smart-GPS-Free-Bus-Tracking-System-RFID-NFC/
│
├── README.md
├── Week_1_Final_Project_Planning_Report.docx
│
├── diagrams/
│   ├── system_architecture.png
│   ├── process_flow.png
│   ├── project_timeline.png
│   └── budget_chart.png
│
└── sample-data/
    └── sample_bus_events.csv
```

## Key Technical Components
### Hardware
- ESP32 or compatible microcontroller
- RFID readers
- RFID tags/cards
- NFC module/cards
- Power supply and prototype components
- Communication interface

### Software
- Embedded firmware
- Backend/API
- Database
- Monitoring dashboard

## Risk Considerations
Important risks considered in the project include:
- Missed RFID reads
- Duplicate RFID events
- Network interruption
- Power failure
- Component availability
- Schedule delays
- Budget variation

Mitigation strategies include field testing, duplicate suppression, local event buffering, retry-based synchronization, milestone reviews and contingency planning.

## Estimated Prototype Budget
The planned prototype budget is approximately **₹6,500**, including a contingency allocation.

## Documentation
The detailed Week 1 internship report contains:
- Project background and objectives
- Detailed requirements analysis
- System architecture
- Process flow diagram
- Realistic assumptions and sample data
- Common pitfalls and controls
- Risk-focused mitigation plan
- Project timeline and milestones
- Resource allocation
- Budget estimation
- Conclusion

## Internship Task
**Week 1 – Project Planning and Requirements Analysis**

This repository is maintained as supporting technical documentation for the internship project.
